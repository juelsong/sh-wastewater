﻿// See https://aka.ms/new-console-template for more information
using RandomDataGenerator;

Console.WriteLine("Hello, World!");
var gen = new ResultGenerator().GetRandomData();
Console.WriteLine(gen);
