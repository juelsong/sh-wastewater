﻿namespace RandomDataGenerator
{
    using System;
    using System.Collections.Generic;

    public enum LimitLevel
    {
        None,
        Alert,
        Action,
        Others
    }
    public class TestReport
    {
        /// <summary>
        /// 报表名称
        /// </summary>
        public string Name { get; set; }

        public string Description { get; set; }

        public DateTime CurrentDateTime { get; set; }
        public string UserName { get; set; }
        public string ComponyName { get; set; }
        public List<Location> LocationsData { get; set; }
    }
    public class Location
    {
        public int LocationId { get; set; }
        public string Environment { get; set; }
        public string Classification { get; set; }
        public string LocationName { get; set; }
        public List<TestTypeData> TestTypeDatas { get; set; }
    }
    public class TestTypeData
    {
        public int LocationId { get; set; }
        public int TestTypeId { get; set; }
        public string TestTypeName { get; set; }
        public List<TestData> TestDatas { get; set; }
    }
    public class TestData
    {
        public int LocationId { get; set; }
        public int TestTypeId { get; set; }
        public int TestId { get; set; }
        public string Name { get; set; }
        public double Value { get; set; }
        public string Barcode { get; set; }
        public DateTime TestDateTime { get; set; }
        public LimitLevel LimitLevel { get; set; }
        public string LimitDescription { get; set; }
    }
    //public class TestData
    //{
    //    public int Id { get; set; }
    //    public List<Meassurement> Meassurements { get; set; }
    //    public string Barcode { get; set; }
    //    public DateTime TestDateTime { get; set; }
    //    public LimitLevel LimitLevel { get; set; }
    //    public string LimitDescription { get; set; }
    //}
    public class Meassurement
    {
        public int Id { get; set; }
        public int MeassurementId { get; set; }
        public string Name { get; set; }
        public double Value { get; set; }
    }
}
